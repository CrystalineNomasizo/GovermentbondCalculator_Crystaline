package com.gvt;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import static jdk.nashorn.internal.objects.NativeMath.round;

public class GovermentBond_A {
    private static final double DAYS_IN_YEAR = 365.0;

    public static void main(String[] args) {
        // Example 1 bond details for R186 bond
        BondDetails R186_bond = new BondDetails(
                LocalDate.of(2026, 12, 21), // maturityDate
                10.5, // couponRate
                100.00, // R (face value of the bond)
                LocalDate.of(2017, 6, 21), // NCD (Next Coupon Date)
                LocalDate.of(2016, 12, 21), // LCD (Last Coupon Date)
                LocalDate.of(2017, 6, 11), // booksCloseDate1
                LocalDate.of(2017, 12, 11), // booksCloseDate2
                LocalDate.of(2017, 2, 7), // settlementDate
                8.75 // yield (market yield)
        );

        System.out.println("\nThe R186 bond results: The R186 bond");
        calculateAndPrint(R186_bond); // Calculate and print results for R186 bond

        // Example 2 bond details for R2032 bond
        BondDetails R2032_bond = new BondDetails(
                LocalDate.of(2032, 3, 31), // maturityDate
                8.25, // couponRate
                100.00, // R (face value of the bond)
                LocalDate.of(2024, 9, 30), // NCD (Next Coupon Date)
                LocalDate.of(2024, 3, 31), // LCD (Last Coupon Date)
                LocalDate.of(2024, 3, 21), // booksCloseDate1
                LocalDate.of(2024, 9, 20), // booksCloseDate2
                LocalDate.of(2024, 5, 16), // settlementDate
                9.5 // yield (market yield)
        );

        System.out.println("\nThe R2032 bond results:");
        calculateAndPrint(R2032_bond); // Calculate and print results for R2032 bond

        // Test case for R186 bond with zero coupon rate
        BondDetails R186_bond_Testcase = new BondDetails(
                LocalDate.of(2026, 12, 21), // maturityDate
                0.00, // couponRate
                100.00, // R (face value of the bond)
                LocalDate.of(2017, 6, 21), // NCD (Next Coupon Date)
                LocalDate.of(2016, 12, 21), // LCD (Last Coupon Date)
                LocalDate.of(2017, 6, 11), // booksCloseDate1
                LocalDate.of(2017, 12, 11), // booksCloseDate2
                LocalDate.of(2017, 2, 7), // settlementDate
                8.75 // yield (market yield)
        );

        System.out.println("\nThe R186 bond results: Test Case with Zero Coupon Bond");
        calculateAndPrint(R186_bond_Testcase); // Calculate and print results for the zero coupon bond

        // Test case for R186 bond with NCD equal to maturity date
        BondDetails R186_bond_Testcase1 = new BondDetails(
                LocalDate.of(2026, 12, 21), // maturityDate
                10.5, // couponRate
                100.00, // R (face value of the bond)
                LocalDate.of(2026, 12, 21), // NCD (Next Coupon Date)
                LocalDate.of(2016, 12, 21), // LCD (Last Coupon Date)
                LocalDate.of(2017, 6, 11), // booksCloseDate1
                LocalDate.of(2017, 12, 11), // booksCloseDate2
                LocalDate.of(2017, 2, 7), // settlementDate
                8.75 // yield (market yield)
        );

        System.out.println("\nThe R186 bond results: Test Case with NCD Equal to Maturity Date");
        calculateAndPrint(R186_bond_Testcase1); // Calculate and print results for the bond with NCD equal to maturity date

        // Test case for R2032 bond with a settlement date after books close date
        BondDetails R2032_bond_Testcase = new BondDetails(
                LocalDate.of(2032, 3, 31), // maturityDate
                8.25, // couponRate
                100.00, // R (face value of the bond)
                LocalDate.of(2024, 9, 30), // NCD (Next Coupon Date)
                LocalDate.of(2024, 3, 31), // LCD (Last Coupon Date)
                LocalDate.of(2024, 9, 21), // booksCloseDate1
                LocalDate.of(2024, 9, 20), // booksCloseDate2
                LocalDate.of(2024, 5, 16), // settlementDate
                9.5 // yield (market yield)
        );

        System.out.println("\nThe R2032 bond results: Test Case with a Settlement Date After Books Close Date");
        calculateAndPrint(R2032_bond_Testcase); // Calculate and print results for the bond with a settlement date after books close date
    }

    // Method to calculate and print bond details
    public static void calculateAndPrint(BondDetails bond) {
        double accruedInterest = calculateAccruedInterest(bond); // Calculate accrued interest
        double aip = calculateAIP(bond); // Calculate All-in Price (AIP)
        double cleanPrice = calculateCleanPrice(aip, accruedInterest); // Calculate clean price
        double dirtyPrice = calculateDirtyPrice(cleanPrice, accruedInterest); // Calculate dirty price

        // Print the calculated values
        System.out.println("Accrued Interest: " + String.format("%.5f", accruedInterest));
        System.out.println("CUMEX: " + String.format("%.5f", (float) bond.calculateCUMEX()));
        System.out.println("N: " + String.format("%.5f", (float) bond.calculateN()));
        System.out.println("AIP: " + String.format("%.5f", aip));
        System.out.println("Clean Price: " + String.format("%.5f", cleanPrice));
        System.out.println("Dirty Price: " + String.format("%.5f", dirtyPrice));
    }

    // Method to calculate accrued interest
    public static double calculateAccruedInterest(BondDetails bond) {
        long daysAccrued = ChronoUnit.DAYS.between(bond.LCD, bond.settlementDate); // Calculate days accrued
        return daysAccrued * bond.couponRate / DAYS_IN_YEAR; // Calculate accrued interest
    }

    // Method to calculate All-in Price (AIP)
    public static double calculateAIP(BondDetails bond) {
        int CUMEX = bond.calculateCUMEX(); // Calculate CUMEX
        double discountFactor = 1 / (1 + (bond.yield / 200)); // Calculate discount factor
        double CPN = bond.couponRate / 2; // Calculate semi-annual coupon
        double CPNatNCD = CPN * CUMEX; // Calculate coupon at NCD
        double BP;

        // Calculate BP based on whether NCD equals maturity date or not.
        if (!bond.NCD.equals(bond.maturityDate)) {
            BP = (double) ChronoUnit.DAYS.between(bond.settlementDate, bond.NCD) / ChronoUnit.DAYS.between(bond.LCD, bond.NCD);
        } else {
            BP = (double) ChronoUnit.DAYS.between(bond.settlementDate, bond.LCD) / (365.0 / 2);
        }

        double BPF;

        // Calculate BPF based on whether NCD equals maturity date or not
        if (!bond.NCD.equals(bond.maturityDate)) {
            BPF = Math.pow(discountFactor, BP);
        } else {
            BPF = discountFactor / (discountFactor + BP / (1 - discountFactor));
        }

        int N = bond.calculateN(); // Calculate N (number of periods)

        // Calculate AIP based on the discount factor
        double AIP;
        if (discountFactor != 1) {
            AIP = BPF * (CPNatNCD + CPN * ((discountFactor * (1 - Math.pow(discountFactor, N))) / (1 - discountFactor)) + bond.R * Math.pow(discountFactor, N));
        } else {
            AIP = CPNatNCD + CPN * N + bond.R;
        }
        return AIP; // Return All-in Price
    }

    // Method to calculate clean price
    public static double calculateCleanPrice(double aip, double accruedInterest) {
        return aip - accruedInterest; // Return the Clean Price = AIP - Accrued Interest
    }

    // Method to calculate dirty price
    public static double calculateDirtyPrice(double cleanPrice, double accruedInterest) {
        return cleanPrice + accruedInterest; // Return the Dirty Price = Clean Price + Accrued Interest
    }
}

// Class to store bond details
class BondDetails {
    LocalDate maturityDate; // Maturity date of the bond
    double couponRate; // Coupon rate of the bond
    double R; // Face value of the bond
    LocalDate NCD; // Next Coupon Date
    LocalDate LCD; // Last Coupon Date
    LocalDate booksCloseDate1; // First books close date
    LocalDate booksCloseDate2; // Second books close date
    LocalDate settlementDate; // Settlement date
    double yield; // Market yield of the bond

    // Constructor to initialize bond details
    public BondDetails(LocalDate maturityDate, double couponRate, double R, LocalDate NCD, LocalDate LCD, LocalDate booksCloseDate1, LocalDate booksCloseDate2, LocalDate settlementDate, double yield) {
        this.maturityDate = maturityDate;
        this.couponRate = couponRate;
        this.R = R;
        this.NCD = NCD;
        this.LCD = LCD;
        this.booksCloseDate1 = booksCloseDate1;
        this.booksCloseDate2 = booksCloseDate2;
        this.settlementDate = settlementDate;
        this.yield = yield;
    }

    // Method to calculate CUMEX (Coupon Ex-Dividend)
    public int calculateCUMEX() {
        if (settlementDate.isBefore(booksCloseDate1) || settlementDate.isBefore(booksCloseDate2)) {
            return 1;
        } else {
            return 0;
        }
    }

    // Method to calculate N (number of periods)
    public int calculateN() {
        return (int) Math.round((double) ChronoUnit.DAYS.between(NCD, maturityDate) / (365.25f / 2));
    }
}
