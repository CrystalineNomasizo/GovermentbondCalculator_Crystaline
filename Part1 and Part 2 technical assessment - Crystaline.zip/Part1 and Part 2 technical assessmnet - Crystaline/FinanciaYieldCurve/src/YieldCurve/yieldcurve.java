package YieldCurve;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;

public class yieldcurve {
    private final List<LocalDate> dates;  // List of dates for the yield curve
    private final List<Double> bidRates;  // List of bid rates corresponding to the dates
    private final List<Double> askRates;  // List of ask rates corresponding to the dates

    // Constructor to initialise the yield curve with dates, bid rates, and ask rates
    public yieldcurve(List<LocalDate> dates, List<Double> bidRates, List<Double> askRates) {
        this.dates = dates;
        this.bidRates = bidRates;
        this.askRates = askRates;
    }

    // Method to get the rate for a given date and rate type (bid, ask, or mid)
    public double getRate(LocalDate date, String rateType) throws Exception {
        // If the date is before the first date in the list, throw an exception
        if (date.isBefore(dates.get(0))) {
            throw new Exception("Date is before the first date in the yield curve.");
        }
//size - 1 ensures that we don't go out of bounds when accessing the dates
        int size = dates.size();// Capture the number of dates in the list
        // If the date is after the last date in the list, use flat extrapolation
        if (date.isAfter(dates.get(size - 1))) {
            return flatExtrapolate(date, rateType);
        }

        // Iterate through the date intervals to find the correct range for interpolation
        for (int i = 0; i < size - 1; i++) //This loop iterates over the list of dates from the beginning (i = 0) to the second-to-last element (i < size - 1).
        {
//The condition has two parts:
            //date.isEqual(dates.get(i)): Checks if the date is exactly equal to the current date 'dates.get(i)'. and date.isAfter(dates.get(i)) && date.isBefore(dates.get(i + 1)): Checks if the date falls strictly between 'dates.get(i)' and 'dates.get(i + 1)'.
//And if  the condition is true, the method proceeds to interpolate the rate for the given date.
            if ((date.isEqual(dates.get(i))) || (date.isAfter(dates.get(i)) && date.isBefore(dates.get(i + 1)))) {
                return interpolate(date, dates.get(i), dates.get(i + 1), getRateByType(rateType, i), getRateByType(rateType, i + 1));
            }
        }

        // This line handles the case where the date is exactly equal to the last date in the dates list.
        return getRateByType(rateType, size - 1);
    }

    // Method to perform linear interpolation between two dates and their corresponding rates
    // Method to perform linear interpolation between two dates and their corresponding rates
    private double interpolate(LocalDate targetDate, LocalDate startDate, LocalDate endDate, double startRate, double endRate) {
        long totalDays = ChronoUnit.DAYS.between(startDate, endDate);  // Total days between the start and end dates
        long targetDays = ChronoUnit.DAYS.between(startDate, targetDate);  // Days from start date to target date

        // Linear interpolation formula
        double interpolatedRate = startRate + (endRate - startRate) * ((double) targetDays / totalDays);
        // Round the interpolated rate to two decimal places
        return Math.round(interpolatedRate * 100.0) / 100.0;
    }

    // Method to return the last known rate if the date is beyond the last date in the list (flat extrapolation)
    private double flatExtrapolate(LocalDate date, String rateType) {
        if (date.isAfter(dates.get(dates.size() - 1))) {
            // Get the rate for the last date in the list
            return getRateByType(rateType, dates.size() - 1);
        }
        return 0.0;  //This value is used as an indication that the rate cannot be determined due to the date falling within the known range of dates but not after the last date.
    }

    // Method to get the rate by type (bid, ask, or mid) for a given index
    private double getRateByType(String rateType, int index) {
        switch (rateType.toLowerCase()) {
            case "bid":
                return bidRates.get(index);
            case "ask":
                return askRates.get(index);
            case "mid":
                // Calculate the mid_rate
                double midRate = (bidRates.get(index) + askRates.get(index)) / 2;
                // Round the mid_rate to the nearest two decimal places
                return Math.round(midRate * 100.0) / 100.0;
            default:
                throw new IllegalArgumentException("Invalid rate type. Use 'bid', 'ask', or 'mid'.");
        }
    }

    public static void main(String[] args) {
        try {
            // Initialize the dates for the yield curve
            List<LocalDate> dates = new ArrayList<>();//A new ArrayList named dates is created to store the dates for the yield curve.
            dates.add(LocalDate.of(2024, 5, 17));
            dates.add(LocalDate.of(2024, 8, 15));
            dates.add(LocalDate.of(2024, 11, 13));
            dates.add(LocalDate.of(2025, 2, 11));
            dates.add(LocalDate.of(2025, 5, 12));
            dates.add(LocalDate.of(2025, 8, 10));
            dates.add(LocalDate.of(2025, 11, 8));
            dates.add(LocalDate.of(2026, 2, 6));
            dates.add(LocalDate.of(2026, 5, 7));

            // Initialize the bid rates corresponding to the dates
            List<Double> bidRates = new ArrayList<>();//A new ArrayList named bidRates is created to store the bidRates for the yield curve.
            bidRates.add(4.50);
            bidRates.add(5.00);
            bidRates.add(6.00);
            bidRates.add(7.20);
            bidRates.add(7.60);
            bidRates.add(8.10);
            bidRates.add(9.00);
            bidRates.add(10.00);
            bidRates.add(11.30);

            // Initialize the ask rates corresponding to the dates
            List<Double> askRates = new ArrayList<>();//A new ArrayList named askRates is created to store the askRates for the yield curve.
            askRates.add(4.55);
            askRates.add(5.05);
            askRates.add(6.05);
            askRates.add(7.25);
            askRates.add(7.65);
            askRates.add(8.15);
            askRates.add(9.05);
            askRates.add(10.05);
            askRates.add(11.35);

            //creates a new instance of the yieldcurve class and initialises it with the provided lists of dates, bid rates, and ask rates
            yieldcurve yc = new yieldcurve(dates, bidRates, askRates);

            // Retrieve and print various rates for different dates and rate types
            System.out.println("Rate (2024-08-15, bid): " + yc.getRate(LocalDate.of(2024, 8, 15), "bid")); // Expected: 5.00 (Exact value from the table)
            System.out.println("Rate (2024-08-15, bid): "+ yc.getRate(LocalDate.of(2024, 8, 15), "mid")); // Expected: 5.025 (Mid_rate between bid and ask)
            System.out.println("Rate (2025-01-01, bid): "+ yc.getRate(LocalDate.of(2025, 1, 1), "mid")); // Expected: 6.67 (Interpolated mid_rate)
            System.out.println("Rate (2025-01-01, bid): "+ yc.getRate(LocalDate.of(2025, 1, 1), "bid")); // Expected: 6.65 (Interpolated bid rate)
            System.out.println("Rate (2026-06-1, bid): "+ yc.getRate(LocalDate.of(2026, 6, 1), "ask")); // Expected: 11.35 (Flat extrapolated ask rate)
            System.out.println("Rate (2023-05-17, bid): "+ yc.getRate(LocalDate.of(2023, 5, 17), "bid")); // Expected: Exception (Date before the first date)
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
