package YieldCurve;

import org.junit.Before;
import org.junit.Test;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.*;

public class YieldCurveTest {

    private yieldcurve yc;

    // Constants for expected values
    private static final double EXPECTED_RATE_20240815_BID = 5.00;
    private static final double EXPECTED_RATE_20250101_BID = 6.65;
    private static final double EXPECTED_RATE_20240815_MID = 5.03;
    private static final double EXPECTED_RATE_20250101_MID = 6.68;
    private static final double EXPECTED_RATE_20260601_ASK = 11.35;
    private static final double DELTA = 0.00001; // Tolerance for floating-point comparisons

    // Setup method to initialize the yield curve before each test
    @Before
    public void setUp() {
        List<LocalDate> dates = new ArrayList<>();
        dates.add(LocalDate.of(2024, 5, 17));
        dates.add(LocalDate.of(2024, 8, 15));
        dates.add(LocalDate.of(2024, 11, 13));
        dates.add(LocalDate.of(2025, 2, 11));
        dates.add(LocalDate.of(2025, 5, 12));
        dates.add(LocalDate.of(2025, 8, 10));
        dates.add(LocalDate.of(2025, 11, 8));
        dates.add(LocalDate.of(2026, 2, 6));
        dates.add(LocalDate.of(2026, 5, 7));

        List<Double> bidRates = new ArrayList<>();
        bidRates.add(4.50);
        bidRates.add(5.00);
        bidRates.add(6.00);
        bidRates.add(7.20);
        bidRates.add(7.60);
        bidRates.add(8.10);
        bidRates.add(9.00);
        bidRates.add(10.00);
        bidRates.add(11.30);

        List<Double> askRates = new ArrayList<>();
        askRates.add(4.55);
        askRates.add(5.05);
        askRates.add(6.05);
        askRates.add(7.25);
        askRates.add(7.65);
        askRates.add(8.15);
        askRates.add(9.05);
        askRates.add(10.05);
        askRates.add(11.35);

        yc = new yieldcurve(dates, bidRates, askRates);
    }

    // Test method for getting bid rates
    @Test
    public void testGetBid() throws Exception {
        // Test for an exact match date
        double rate = yc.getRate(LocalDate.of(2024, 8, 15), "bid");
        System.out.println("Rate (2024-08-15, bid): " + rate);
        assertEquals(EXPECTED_RATE_20240815_BID, rate, DELTA);

        // Test for an interpolated date
        rate = yc.getRate(LocalDate.of(2025, 1, 1), "bid");
        System.out.println("Rate (2025-01-01, bid): " + rate);
        assertEquals(EXPECTED_RATE_20250101_BID, rate, DELTA);

        // Test for a date before the first date in the yield curve (should throw an exception)
        assertThrows(Exception.class, () -> yc.getRate(LocalDate.of(2023, 5, 17), "bid"));
    }

    // Test method for getting mid rates
    @Test
    public void testGetMid() throws Exception {
        // Test for an exact match date
        double rate = yc.getRate(LocalDate.of(2024, 8, 15), "mid");
        System.out.println("Rate (2024-08-15, mid): " + rate);
        assertEquals(EXPECTED_RATE_20240815_MID, rate, DELTA);

        // Test for an interpolated date
        rate = yc.getRate(LocalDate.of(2025, 1, 1), "mid");
        System.out.println("Rate (2025-01-01, mid): " + rate);
        assertEquals(EXPECTED_RATE_20250101_MID, rate, DELTA);
    }

    // Test method for getting ask rates
    @Test
    public void testGetAsk() throws Exception {
        // Test for a date beyond the last date in the yield curve (flat extrapolation)
        double rate = yc.getRate(LocalDate.of(2026, 6, 1), "ask");
        System.out.println("Rate (2026-06-01, ask): " + rate);
        assertEquals(EXPECTED_RATE_20260601_ASK, rate, DELTA);
    }

    // Test method for checking exception handling when the date is before the first date in the yield curve
    @Test
    public void testExceptionForDateBeforeFirstDate() {
        // This should throw an exception because the date is before the first date in the yield curve
        Exception exception = assertThrows(Exception.class, () -> yc.getRate(LocalDate.of(2023, 5, 17), "bid"));
        // Expected: Exception
        System.out.println("Exception for date before the first date: " + exception.getMessage());
    }
}
